
package ch3ex1;

public class Ch3ex1 {

    // BingoCard Application
    public static void main(String[] args) {

        System.out.println("B		I		N		G		O");
        System.out.println("2		20		42		60		64");
        System.out.println("14		25		32		55		70");
        System.out.println("5		18	    	FREE	 	53		67");
        System.out.println("12		16		39		59		71");


    }

}    

