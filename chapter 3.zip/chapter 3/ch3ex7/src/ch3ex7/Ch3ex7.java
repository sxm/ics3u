package ch3ex7;

/**
 *
 * @author swaheed9387
 */
public class Ch3ex7 {

    // BingoCard Application
    public static void main(String[] args) {

        // The head is made out of 9 (*)
        System.out.println("    *****");
        System.out.println("   *     *");
        System.out.println("  * _   _ *");
        System.out.println(" *  o   o  *");
        System.out.println("*     |     *");
        System.out.println("*     +     *");
        System.out.println(" *         *");
        System.out.println("  *  \\__/ *");
        System.out.println("   *     *");
        System.out.println("    *****");

    }

}